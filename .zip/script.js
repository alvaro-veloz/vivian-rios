/* =====================================================
   Dra. Johana — Script principal
   GSAP + Three.js + Cursor + Counters + Interactions
   Andina Web Studio
   ===================================================== */

/* ── Year ── */
document.getElementById('nav-year').textContent = new Date().getFullYear();
document.getElementById('footer-year').textContent = new Date().getFullYear();

/* ── Custom Cursor ── */
(function customCursor() {
  const cursor = document.getElementById('cursor');
  const follower = document.getElementById('cursorFollower');
  let fx = 0, fy = 0, cx = 0, cy = 0;

  document.addEventListener('mousemove', (e) => {
    cx = e.clientX;
    cy = e.clientY;
    cursor.style.left = cx + 'px';
    cursor.style.top  = cy + 'px';
  });

  function animate() {
    fx += (cx - fx) * 0.12;
    fy += (cy - fy) * 0.12;
    follower.style.left = fx + 'px';
    follower.style.top  = fy + 'px';
    requestAnimationFrame(animate);
  }
  animate();
})();

/* ── Navbar hide on scroll down ── */
(function navHide() {
  const nav = document.getElementById('nav');
  let lastY = 0;
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    nav.classList.toggle('hidden', y > lastY && y > 80);
    lastY = y;
  }, { passive: true });
})();

/* ── Three.js — Floating organic particles ── */
(function initThree() {
  const canvas = document.getElementById('heroCanvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(canvas.offsetWidth, canvas.offsetHeight);
  renderer.setClearColor(0x000000, 0);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, canvas.offsetWidth / canvas.offsetHeight, 0.1, 100);
  camera.position.z = 5;

  /* ── Main torus knot — medical feel ── */
  const knotGeo = new THREE.TorusKnotGeometry(1.2, 0.38, 160, 32, 2, 3);
  const knotMat = new THREE.MeshPhongMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.18,
    wireframe: false,
    shininess: 80,
    specular: new THREE.Color(0xffffff),
  });
  const knotMesh = new THREE.Mesh(knotGeo, knotMat);
  scene.add(knotMesh);

  /* Wireframe overlay */
  const wireMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    wireframe: true,
    transparent: true,
    opacity: 0.06,
  });
  const wireMesh = new THREE.Mesh(knotGeo, wireMat);
  scene.add(wireMesh);

  /* ── Floating particles ── */
  const partCount = 180;
  const positions = new Float32Array(partCount * 3);
  for (let i = 0; i < partCount; i++) {
    positions[i * 3]     = (Math.random() - 0.5) * 12;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 8;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 6;
  }
  const partGeo = new THREE.BufferGeometry();
  partGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const partMat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.025,
    transparent: true,
    opacity: 0.45,
  });
  const particles = new THREE.Points(partGeo, partMat);
  scene.add(particles);

  /* ── Lights ── */
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);
  const dirLight = new THREE.DirectionalLight(0xC17F59, 1.2);
  dirLight.position.set(3, 3, 3);
  scene.add(dirLight);
  const dirLight2 = new THREE.DirectionalLight(0x8AAAB8, 0.8);
  dirLight2.position.set(-3, -2, 2);
  scene.add(dirLight2);

  /* ── Mouse parallax ── */
  let mouseX = 0, mouseY = 0, targetX = 0, targetY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  /* ── Resize ── */
  window.addEventListener('resize', () => {
    const w = canvas.offsetWidth, h = canvas.offsetHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });

  /* ── Animate ── */
  let t = 0;
  function tick() {
    requestAnimationFrame(tick);
    t += 0.006;

    targetX += (mouseX * 0.5 - targetX) * 0.04;
    targetY += (mouseY * 0.5 - targetY) * 0.04;

    knotMesh.rotation.x = t * 0.25 + targetY * 0.4;
    knotMesh.rotation.y = t * 0.35 + targetX * 0.4;
    wireMesh.rotation.x = knotMesh.rotation.x;
    wireMesh.rotation.y = knotMesh.rotation.y;

    particles.rotation.y = t * 0.05 + targetX * 0.1;
    particles.rotation.x = targetY * 0.08;

    renderer.render(scene, camera);
  }
  tick();
})();

/* ── GSAP Hero text reveal ── */
(function heroReveal() {
  if (typeof gsap === 'undefined') return;

  gsap.registerPlugin(ScrollTrigger);

  const words = document.querySelectorAll('.hero-word');
  gsap.to(words, {
    y: 0,
    opacity: 1,
    duration: 1.1,
    ease: 'power4.out',
    stagger: 0.12,
    delay: 0.3,
  });
})();

/* ── Intersection Observer for generic .is-inview ── */
(function inview() {
  const els = document.querySelectorAll('[data-stat], .service-card');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('is-inview'), i * 80);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  els.forEach(el => obs.observe(el));
})();

/* ── Animated counters ── */
(function counters() {
  const items = document.querySelectorAll('[data-count]');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const duration = 1800;
      const start = performance.now();

      function step(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease out cubic
        el.textContent = Math.floor(eased * target);
        if (progress < 1) requestAnimationFrame(step);
        else el.textContent = target;
      }
      requestAnimationFrame(step);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  items.forEach(el => obs.observe(el));
})();

/* ── GSAP ScrollTrigger — about & CTA reveals ── */
(function scrollReveal() {
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

  gsap.registerPlugin(ScrollTrigger);

  // About section
  gsap.from('.about-photo-frame', {
    scrollTrigger: { trigger: '.about-section', start: 'top 75%' },
    x: -60, opacity: 0, duration: 1.2, ease: 'power4.out',
  });
  gsap.from('.about-text-col > *', {
    scrollTrigger: { trigger: '.about-section', start: 'top 70%' },
    y: 40, opacity: 0, duration: 1, ease: 'power3.out', stagger: 0.1,
  });

  // CTA
  gsap.from('.cta-title, .cta-sub, .cta-actions, .cta-hours-detail', {
    scrollTrigger: { trigger: '.cta-section', start: 'top 70%' },
    y: 50, opacity: 0, duration: 1, ease: 'power3.out', stagger: 0.12,
  });

  // Testimonials
  gsap.from('.testimonials-inner', {
    scrollTrigger: { trigger: '.testimonials-section', start: 'top 75%' },
    y: 40, opacity: 0, duration: 1, ease: 'power3.out',
  });

  // Services title
  gsap.from('.services-title', {
    scrollTrigger: { trigger: '.services-section', start: 'top 80%' },
    y: 60, opacity: 0, duration: 1.2, ease: 'power4.out',
  });
})();

/* ── Services horizontal drag scroll + progress bar ── */
(function servicesScroll() {
  const wrap = document.getElementById('servicesWrap');
  const progress = document.getElementById('servicesProgress');
  if (!wrap || !progress) return;

  // Update progress bar
  wrap.addEventListener('scroll', () => {
    const max = wrap.scrollWidth - wrap.clientWidth;
    const pct = max > 0 ? (wrap.scrollLeft / max) * 100 : 0;
    progress.style.width = pct + '%';
  }, { passive: true });

  // Drag to scroll
  let isDown = false, startX, scrollLeft;
  wrap.addEventListener('mousedown', (e) => {
    isDown = true;
    startX = e.pageX - wrap.offsetLeft;
    scrollLeft = wrap.scrollLeft;
  });
  document.addEventListener('mouseup', () => isDown = false);
  document.addEventListener('mouseleave', () => isDown = false);
  wrap.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - wrap.offsetLeft;
    const walk = (x - startX) * 1.5;
    wrap.scrollLeft = scrollLeft - walk;
  });
})();

/* ── Testimonials auto-rotate ── */
(function testimonials() {
  const items = document.querySelectorAll('.testimonial');
  const dots  = document.querySelectorAll('.t-dot');
  let current = 0;
  let timer;

  function show(idx) {
    items[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = idx;
    items[current].classList.add('active');
    dots[current].classList.add('active');
  }

  function next() {
    show((current + 1) % items.length);
  }

  function startTimer() {
    timer = setInterval(next, 4500);
  }

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      clearInterval(timer);
      show(parseInt(dot.dataset.idx));
      startTimer();
    });
  });

  startTimer();
})();

/* ── Service cards: open WhatsApp on click ── */
document.querySelectorAll('.service-card-cta, .service-card').forEach(el => {
  el.addEventListener('click', () => {
    window.open('https://wa.me/593989999999?text=Hola%20Dra.%20Johana%2C%20quiero%20agendar%20una%20cita', '_blank');
  });
});
